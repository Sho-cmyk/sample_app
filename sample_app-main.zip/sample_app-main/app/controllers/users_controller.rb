class UsersController < ApplicationController
  def new
    # => GET app/views/users/new.html.erb
  end
end
